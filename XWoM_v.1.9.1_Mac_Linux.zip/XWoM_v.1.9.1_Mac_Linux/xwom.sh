#!/bin/sh
java -Xmx832M -Xms832M -jar -Dsun.java2d.noddraw=true -Dsun.awt.noerasebackground=true -Dsun.java2d.d3d=false -Dsun.java2d.opengl=false -Dsun.java2d.pmoffscreen=false lib/Starter.jar